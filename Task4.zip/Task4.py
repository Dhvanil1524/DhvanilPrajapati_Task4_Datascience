#!/usr/bin/env python
# coding: utf-8

# In[14]:


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import matplotlib
matplotlib.use('TkAgg')  


plt.ion()  

x = np.linspace(-5, 5, 100)
y = np.linspace(-5, 5, 100)
X, Y = np.meshgrid(x, y)
Z = np.sin(np.sqrt(X**2 + Y**2))

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection='3d')


colormap = plt.cm.viridis 
surface = ax.plot_surface(X, Y, Z, cmap=colormap, edgecolor='none')


fig.colorbar(surface, ax=ax, shrink=0.5, aspect=10)


ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.set_zlabel('Z axis')


ax.set_title('3D Surface Plot with Custom Colormap and Shading')

plt.savefig('3d_surface_plot_debugged.png') 
plt.show()

